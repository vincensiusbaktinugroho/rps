<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rps extends Model
{
    protected $fillable =[
        'mata_kuliah_id',
        'nama'];

        public function Matakuliah()
        {
            return $this->belongsTo(MataKuliah::class);
        }
}

