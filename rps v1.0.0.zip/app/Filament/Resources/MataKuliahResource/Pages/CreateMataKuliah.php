<?php

namespace App\Filament\Resources\MataKuliahResource\Pages;

use App\Filament\Resources\MataKuliahResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMataKuliah extends CreateRecord
{
    protected static string $resource = MataKuliahResource::class;
}
