<?php

namespace App\Filament\Resources\SubCpmkResource\Pages;

use App\Filament\Resources\SubCpmkResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSubCpmk extends CreateRecord
{
    protected static string $resource = SubCpmkResource::class;
}
