<?php

namespace App\Filament\Resources\RpsResource\Pages;

use App\Filament\Resources\RpsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRps extends CreateRecord
{
    protected static string $resource = RpsResource::class;
}
