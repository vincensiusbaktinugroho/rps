<?php

namespace App\Filament\Resources\CplProdiResource\Pages;

use App\Filament\Resources\CplProdiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCplProdi extends CreateRecord
{
    protected static string $resource = CplProdiResource::class;
}
